### Custom definitions and classes if any ###

def predictRuns(testInput):
    prediction = 0
    ### Your Code Here ###
    return prediction
